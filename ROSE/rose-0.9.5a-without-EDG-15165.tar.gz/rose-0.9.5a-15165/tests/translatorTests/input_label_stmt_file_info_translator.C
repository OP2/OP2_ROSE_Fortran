int main ()
{
    double alpha = 0.5;
    
label1: alpha = 1.5;

    return 0;
}

