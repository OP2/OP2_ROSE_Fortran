int x;

int main()
   {
     x = preinclude_y;
     return 0;
   }
