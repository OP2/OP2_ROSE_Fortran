class Bar {};

void foo() {
   try {
   } catch (Bar) {
   }
}
