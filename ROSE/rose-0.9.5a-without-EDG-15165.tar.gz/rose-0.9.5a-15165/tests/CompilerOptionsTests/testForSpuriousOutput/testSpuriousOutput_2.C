
#include <list>

std::list<int> l;
