

// Use correct include file depending whether templates are used or not

#if defined(USE_TEMPLATES)
#   include "descriptor_templates.h"
#else
#   include "descriptor_notemplates.h"
#endif

