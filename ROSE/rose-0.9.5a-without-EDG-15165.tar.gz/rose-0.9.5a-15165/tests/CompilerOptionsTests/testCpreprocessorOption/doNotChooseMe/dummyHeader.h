#error "Chose the wrong header. For system includes GCC first looks inside the directories specified by '-I', then into the system include directories."
