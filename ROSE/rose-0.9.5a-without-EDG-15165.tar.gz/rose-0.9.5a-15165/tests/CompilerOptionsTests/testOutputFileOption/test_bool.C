#if !defined(USE_ROSE)
   #define bool int
   #define true   1
   #define false  0
#endif

int
main ()
   {
     bool x = true;
     return (x == true) ? 1 : 0;
   }
