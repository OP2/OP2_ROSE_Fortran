/*A header: with correct type decl, 
 * this header is at the same directory as the source file including it, 
 * it should be searched first */
#define Aaa 1;
int bar(int i);
