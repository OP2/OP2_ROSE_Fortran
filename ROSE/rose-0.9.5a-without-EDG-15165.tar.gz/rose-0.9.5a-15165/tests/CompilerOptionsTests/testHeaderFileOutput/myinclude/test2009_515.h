/*A header : with conflicting type decl*/
#define Aaa 1;
int bar(char i);
