// Test code for token stream handling

int
main()
   {
     int x = -1;
     if (true)
        {
          x = 0;
        }
       else
          x = 1;

     return 0;
   }
