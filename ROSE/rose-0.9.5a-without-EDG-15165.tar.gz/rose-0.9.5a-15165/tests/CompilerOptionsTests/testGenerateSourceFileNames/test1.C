void foo(){};

int main()
{
};
