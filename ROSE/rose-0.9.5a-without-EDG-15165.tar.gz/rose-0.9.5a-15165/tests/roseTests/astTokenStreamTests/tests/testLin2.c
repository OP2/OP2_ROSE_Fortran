#include <math.h>

int main()
{
    double A4, MmP, lP, Lambdasun;
      A4 = ((Lambdasun - 0.1114041 * A4 - Lambdasun) - 360.0 * (floor((Lambdasun - 0.1114041 * A4 - Lambdasun) / 360.0)));

};

