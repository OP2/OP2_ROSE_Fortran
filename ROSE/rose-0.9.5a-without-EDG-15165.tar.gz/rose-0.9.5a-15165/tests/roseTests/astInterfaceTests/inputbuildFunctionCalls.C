/// goal 1. generate
//  foo(p_sum);
// goal 2. generate
//  foo(0.5);
//   after inserting its header

// how parameter is used
void foo(int x);

int main (void)
{
  int p_sum=0;
  return p_sum;
}

