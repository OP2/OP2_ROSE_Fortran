extern int foo(int);
int main()
{
  int a, b, c;
  a = b + c;
  return 0;  
}
