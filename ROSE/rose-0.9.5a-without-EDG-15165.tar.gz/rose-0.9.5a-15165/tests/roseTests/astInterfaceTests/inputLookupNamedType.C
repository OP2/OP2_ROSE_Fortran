typedef int name2;

struct name3
	{
	char name[50];
	int magazinesize;
	float calibre;
	};
enum name
{
  e_unknown = 0
};

typedef struct name3 name1;
