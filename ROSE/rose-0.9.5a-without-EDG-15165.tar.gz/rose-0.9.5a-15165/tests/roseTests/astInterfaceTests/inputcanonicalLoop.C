int a[100];
int j;
int main(void)
{
  for (int i=0;i<100;i+=1)
    a[i]=i;
  return 0;
}

