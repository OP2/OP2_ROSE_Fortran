
extern void foo();
