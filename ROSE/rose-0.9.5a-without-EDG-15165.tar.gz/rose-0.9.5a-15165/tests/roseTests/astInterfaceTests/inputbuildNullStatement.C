#define UPCR_TLD_DEFINE(name, size, align) name

void foo(){};
int main()
{
  return 0;
}
