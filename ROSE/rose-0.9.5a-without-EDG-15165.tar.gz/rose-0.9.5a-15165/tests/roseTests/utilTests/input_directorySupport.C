// Input test problem so that we can test the new SgDirectory IR node.

int main()
   {
     return 0;
   }
