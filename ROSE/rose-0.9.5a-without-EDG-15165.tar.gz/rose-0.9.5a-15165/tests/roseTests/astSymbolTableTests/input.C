
int x;

void foo()
   {
     x = 42;
   }
