int main()
{
  int x = 9;
  x = x + 1;
} 
