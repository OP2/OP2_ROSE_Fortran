
int main()
   {
     int x = 0;
     if (x)
          x++;

     return x;
   }
