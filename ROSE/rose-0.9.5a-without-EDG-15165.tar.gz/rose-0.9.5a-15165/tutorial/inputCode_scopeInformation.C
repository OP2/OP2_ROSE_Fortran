
int xyz;

void foo (int x)
   {
     int y;
     for (int i=0; i < 10; i++)
        {
          int z;
          z = 42;
        }
   }



