int 
foo()
   {
     int x = 42;
     return x;
   }




