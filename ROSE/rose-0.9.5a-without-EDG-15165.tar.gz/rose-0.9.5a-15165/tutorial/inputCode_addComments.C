
int 
foo()
   {
     int x = 2;
     x += 3 + 4;
     return x;
   }

