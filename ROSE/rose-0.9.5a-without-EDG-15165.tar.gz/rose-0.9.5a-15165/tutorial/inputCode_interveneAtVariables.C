int main() {
   int x = 34;
   int y = 34;
   int z = 56;

   x = 5;
   y=x;
   z = x+y;
   z = x + x + x;
   z = x = y;
   return z;
}
