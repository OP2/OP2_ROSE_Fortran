template <typename T>
class X
   {
     public:
         void foo();
   };

X<int> x;

void X<int>::foo()
   {
   }

