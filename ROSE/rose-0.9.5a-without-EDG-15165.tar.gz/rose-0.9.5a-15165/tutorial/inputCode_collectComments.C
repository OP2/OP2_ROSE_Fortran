
// #include<stdio.h>

#define SOURCE_CODE_BEFORE_INCLUDE_A
#define SOURCE_CODE_BEFORE_INCLUDE_B
#include<inputCode_collectComments.h>
#define SOURCE_CODE_AFTER_INCLUDE_A
#define SOURCE_CODE_AFTER_INCLUDE_B

// main program: collectComments input test code
int main()
   {
     return 0;
   }
