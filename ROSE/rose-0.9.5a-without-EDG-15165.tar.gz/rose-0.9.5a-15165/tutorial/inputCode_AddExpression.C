int main()
{
  double alpha= 0.5;
  double beta = 0.1;
  double gama = 0.7;

  return 0;
}

