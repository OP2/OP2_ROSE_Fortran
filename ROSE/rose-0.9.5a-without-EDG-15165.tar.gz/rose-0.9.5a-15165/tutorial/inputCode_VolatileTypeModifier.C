// Input example of use of "volatile" type modifier

volatile int a,*b;

void foo()
   {
     for (volatile int y = 0; y < 10; y++)
        {
        }
   }
