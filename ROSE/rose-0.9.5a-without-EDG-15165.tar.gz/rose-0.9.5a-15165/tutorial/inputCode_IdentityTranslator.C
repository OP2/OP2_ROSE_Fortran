// Example input file for ROSE tutorial
#include <iostream>

typedef float Real;

// Main function
int main()
   {
     int x = 0;
     bool value = false;

  // for loop
     for (int i=0; i < 4; i++)
        {
          int x;
        }

     return 0;
   }
