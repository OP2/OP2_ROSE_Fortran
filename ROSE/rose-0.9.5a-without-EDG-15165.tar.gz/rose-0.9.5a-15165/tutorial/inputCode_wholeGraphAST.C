int x;

#if 0
int
main()
   {
     int x = 0;

     return 0;
   }
#endif
