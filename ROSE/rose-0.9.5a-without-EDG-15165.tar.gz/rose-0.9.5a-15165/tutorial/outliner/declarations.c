void foo()
{
  int i;
  int k;
  i=k;
}
