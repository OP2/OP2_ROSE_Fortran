int a[100], sum;
int  main()
{
  int i,sum2,yy,zz;
  sum = 0;
  for (i=0;i<100;i++)
  {
    int xx;
    a[i]=i;
    sum = a[i]+ sum;
    xx++;
    yy=0;
    yy--;
    zz*=a[i];
  }
  return 0;
}

