class A{};

class B : public A{};

class C : public B{};
