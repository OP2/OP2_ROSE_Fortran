int x;
int y;
long z;
float pressure;

int main()
   {
     int a = 0;
     int b = 0;
     float density = 1.0;

     x++;
     b++;

     x = a + y;

     return 0;
   }
