
// This is a test code for the Interl Pin support in ROSE,
// it is used as input to the ROSE pin tool (run by pin).
int
main()
   {
     int x = 0;
     for (int i=0; i < 10; i++)
        {
          x++;
        }
      
     return 0;
   }
