
void foobar()
   {
  // Static array declaration
     float array[10];

     array[0] = 0;

     for (int i=0; i < 5; i++)
        {
          array[i] = 0;
        }
   }

