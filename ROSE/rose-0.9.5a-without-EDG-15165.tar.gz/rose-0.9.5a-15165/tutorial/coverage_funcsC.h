void coverageTraceFunc1(const char* FileMethod);
