void bar(int x);
namespace space1
{
  class A
  {
  public:  
    void bar(int x);
    void foo();
  };
}

