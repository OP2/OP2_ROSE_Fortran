// Trivial function used to generate graph of AST
// with all types and additional edges shown.
// Graphs of this sort are large, and can be
// viewed using "zgrviewer" for dot files.
int foo()
   {
     return 0;
   }
