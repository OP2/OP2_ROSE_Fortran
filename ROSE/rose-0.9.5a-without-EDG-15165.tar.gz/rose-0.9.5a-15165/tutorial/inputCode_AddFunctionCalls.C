// Overloaded functions for testing overloaded function resolution
void foo(double)
   {
     int x = 1;
     int y;

     if (x) y = 1; else y = 2;
   }

