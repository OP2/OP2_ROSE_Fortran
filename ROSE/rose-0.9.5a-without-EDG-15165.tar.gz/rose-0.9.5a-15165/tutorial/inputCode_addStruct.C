
int b;

void foo()
   {
   }


