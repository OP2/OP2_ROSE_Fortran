// Overloaded functions for testing overloaded function resolution
void foo(double)
   {
     int x = 1;
     int y;

  // I think that this case fails currently
  // if (x) y = 1; else y = 2;
   }

