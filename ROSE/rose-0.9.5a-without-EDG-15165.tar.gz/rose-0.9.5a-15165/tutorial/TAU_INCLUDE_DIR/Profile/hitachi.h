#include <string.h>
#include <strings.h>
