#define TAU_i386_linux
#define TAU_ARCH "i386_linux"
