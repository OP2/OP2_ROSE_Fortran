using namespace std;

int main(int argc, char** argv) {
  int* x= new int[2];
  int* k ;
  x[1]=2;
  x[2]=3;
  int y=x[5];
  int a=x[0]/y;

  x[0]=*k;
}
