float gam, gm1, cfl, eps, mach, alpha, qinf[4];
